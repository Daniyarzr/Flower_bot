from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from time import time
from typing import Dict, List, Optional, Tuple

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, FSInputFile, Message
from sqlalchemy import select, func, update
from sqlalchemy.orm import selectinload

from app.config import Config
from app.db import get_sessionmaker, upsert_user
from app.keyboards import (
    kb_after_request_sent,
    kb_confirm,
    kb_delivery_type,
    kb_main_menu_bottom,
    kb_my_request_view,
    kb_my_requests_list,
    kb_payment_type,
    kb_price_filters,
    kb_product_nav,
    kb_skip_comment,
    kb_start,
    kb_confirm_cancel_my_req
)
from app.models import (
    BotText, CategoryEnum, Product, Request, 
    RequestStatus, User, UserRole, DeliveryType, PaymentType
)
from app.states import RequestFSM
from app.utils import is_admin_cached, safe_edit, tg_user_link

router = Router(name="user_router")
logger = logging.getLogger(__name__)

# ==========================
# Catalog Cache & Logic
# ==========================
CATALOG_CACHE: Dict[tuple, Tuple[List[Product], float]] = {}
CACHE_TTL = 300  # 5 минут

async def get_products_filtered(category: str, min_p: int, max_p: int) -> List[Product]:
    cache_key = (category, min_p, max_p)
    now = time()
    
    if cache_key in CATALOG_CACHE:
        products, timestamp = CATALOG_CACHE[cache_key]
        if now - timestamp < CACHE_TTL:
            return products

    async with get_sessionmaker()() as session:
        stmt = select(Product).where(Product.category == CategoryEnum(category))
        if min_p > 0:
            stmt = stmt.where(Product.price >= min_p)
        if max_p > 0:
            stmt = stmt.where(Product.price <= max_p)
        
        stmt = stmt.order_by(Product.id.desc())
        result = await session.execute(stmt)
        products = list(result.scalars().all())
        
        CATALOG_CACHE[cache_key] = (products, now)
        return products

# ==========================
# Основные хендлеры
# ==========================

@router.message(F.text == "/start")
async def cmd_start(m: Message, config: Config):
    async with get_sessionmaker()() as session:
        await upsert_user(
            session,
            tg_id=m.from_user.id,
            username=m.from_user.username,
            first_name=m.from_user.first_name,
            admin_ids=config.admin_ids
        )
        res = await session.execute(select(BotText).where(BotText.key == "start_message"))
        bt = res.scalar_one_or_none()
        text = bt.value if bt else f"🌸 Добро пожаловать в <b>{config.shop_name}</b>!"

    is_admin = await is_admin_cached(m.from_user.id)
    await m.answer(text, reply_markup=kb_start(is_admin))

@router.callback_query(F.data == "back:start")
async def back_to_start(c: CallbackQuery, config: Config):
    await c.answer()
    is_admin = await is_admin_cached(c.from_user.id)
    async with get_sessionmaker()() as session:
        res = await session.execute(select(BotText).where(BotText.key == "start_message"))
        bt = res.scalar_one_or_none()
        text = bt.value if bt else f"🌸 Добро пожаловать в <b>{config.shop_name}</b>!"
    await safe_edit(c, text=text, reply_markup=kb_start(is_admin))

# ==========================
# Логика каталога
# ==========================

@router.callback_query(F.data.startswith("cat:"))
async def catalog_category_selected(c: CallbackQuery):
    await c.answer()
    category = c.data.split(":")[1]
    await safe_edit(
        c,
        text="<b>💰 Выберите ценовой диапазон:</b>\nМы подберем лучшие варианты под ваш бюджет.",
        reply_markup=kb_price_filters(category)
    )

@router.callback_query(F.data.startswith("filter:"))
async def filter_select(c: CallbackQuery):
    await c.answer()
    parts = c.data.split(":")
    cat, min_p, max_p = parts[1], int(parts[2]), int(parts[3])
    await show_product(c, cat, min_p, max_p, 0)

async def show_product(c: CallbackQuery, cat: str, min_p: int, max_p: int, index: int):
    products = await get_products_filtered(cat, min_p, max_p)

    if not products:
        return await safe_edit(c, "😔 В этой категории пока нет подходящих товаров.", reply_markup=kb_start())

    if index < 0: index = len(products) - 1
    if index >= len(products): index = 0
    
    p = products[index]
    caption = (
        f"<b>{p.title}</b>\n\n"
        f"📝 {p.description or 'Описание скоро появится...'}\n"
        f"💰 Цена: <b>{p.price} ₽</b>\n\n"
        f"📍 Товар {index + 1} из {len(products)}"
    )
    kb = kb_product_nav(cat, min_p, max_p, index, p.id)

    if p.photo_path and Path(p.photo_path).exists():
        photo = FSInputFile(p.photo_path)
        try:
            # При смене товара лучше удалять старое сообщение, чтобы избежать ошибок смены Media
            await c.message.delete()
            await c.message.answer_photo(photo=photo, caption=caption, reply_markup=kb)
        except Exception:
            await c.message.answer(caption, reply_markup=kb)
    else:
        await safe_edit(c, caption, reply_markup=kb)

@router.callback_query(F.data.startswith("nav:"))
async def nav_callback(c: CallbackQuery):
    await c.answer()
    parts = c.data.split(":")
    cat, min_p, max_p, idx = parts[1], int(parts[2]), int(parts[3]), int(parts[4])
    await show_product(c, cat, min_p, max_p, idx)

# ==========================
# Мои заявки (Список и просмотр)
# ==========================

@router.callback_query(F.data == "my:req:list")
async def my_requests_list(c: CallbackQuery):
    await c.answer()
    async with get_sessionmaker()() as session:
        res = await session.execute(
            select(Request)
            .join(User)
            .where(User.tg_id == c.from_user.id)
            .order_by(Request.created_at.desc())
        )
        reqs = res.scalars().all()

    if not reqs:
        return await safe_edit(c, "У вас пока нет созданных заявок.", reply_markup=kb_main_menu_bottom())

    items = []
    for r in reqs:
        label = f"#{r.id} | {r.status.value.upper()} | {r.created_at.strftime('%d.%m')}"
        items.append((r.id, label))

    await safe_edit(c, "<b>📦 Ваши последние заказы:</b>", reply_markup=kb_my_requests_list(items))

@router.callback_query(F.data.startswith("my:req:view:"))
async def my_request_view(c: CallbackQuery):
    await c.answer()
    req_id = int(c.data.split(":")[3])
    async with get_sessionmaker()() as session:
        res = await session.execute(
            select(Request).where(Request.id == req_id).options(selectinload(Request.product))
        )
        r = res.scalar_one_or_none()

    if not r:
        return await c.answer("Заявка не найдена", show_alert=True)

    text = (
        f"<b>Заявка #{r.id}</b>\n\n"
        f"🌸 Товар: {r.product.title if r.product else 'Удален'}\n"
        f"📌 Статус: <b>{r.status.value.upper()}</b>\n"
        f"📅 Создана: {r.created_at.strftime('%d.%m.%Y %H:%M')}\n"
        f"💬 Коммент: {r.comment or '—'}"
    )
    can_cancel = r.status == RequestStatus.NEW
    await safe_edit(c, text, reply_markup=kb_my_request_view(r.id, can_cancel))

@router.callback_query(F.data.startswith("my:req:cancel:"))
async def my_req_cancel_confirm(c: CallbackQuery):
    await c.answer()
    req_id = int(c.data.split(":")[3])
    await safe_edit(c, "Вы уверены, что хотите отменить эту заявку?", reply_markup=kb_confirm_cancel_my_req(req_id))

@router.callback_query(F.data.startswith("my:req:cancel_yes:"))
async def my_req_cancel_execute(c: CallbackQuery):
    req_id = int(c.data.split(":")[3])
    async with get_sessionmaker()() as session:
        await session.execute(
            update(Request).where(Request.id == req_id).values(status=RequestStatus.CANCELED)
        )
        await session.commit()
    await c.answer("✅ Заявка отменена", show_alert=True)
    await my_requests_list(c)

# ==========================
# Поддержка
# ==========================

@router.callback_query(F.data == "support")
async def support_info(c: CallbackQuery, config: Config):
    await c.answer()
    async with get_sessionmaker()() as session:
        res = await session.execute(select(BotText).where(BotText.key == "support_message"))
        bt = res.scalar_one_or_none()
        text = bt.value if bt else f"💌 По всем вопросам пишите нам: {config.support_contact}"
    await safe_edit(c, text, reply_markup=kb_main_menu_bottom())

# ==========================
# Оформление заказа (FSM)
# ==========================

@router.callback_query(F.data.startswith("order:btn:"))
async def start_order(c: CallbackQuery, state: FSMContext):
    await c.answer()
    product_id = int(c.data.split(":")[2])
    await state.update_data(product_id=product_id)
    await state.set_state(RequestFSM.customer_name)
    await c.message.answer("👤 <b>Напишите ваше имя:</b>")

@router.message(RequestFSM.customer_name)
async def process_name(m: Message, state: FSMContext):
    await state.update_data(customer_name=m.text)
    await state.set_state(RequestFSM.phone)
    await m.answer("📱 <b>Введите номер телефона для связи:</b>")

@router.message(RequestFSM.phone)
async def process_phone(m: Message, state: FSMContext):
    await state.update_data(phone=m.text)
    await state.set_state(RequestFSM.delivery_type)
    await m.answer("🚚 <b>Выберите способ получения:</b>", reply_markup=kb_delivery_type())

@router.callback_query(RequestFSM.delivery_type)
async def process_delivery(c: CallbackQuery, state: FSMContext):
    await c.answer()
    dt = c.data.split(":")[1]
    await state.update_data(delivery_type=dt)
    if dt == "delivery":
        await state.set_state(RequestFSM.address)
        await c.message.answer("🏠 <b>Введите адрес доставки:</b>")
    else:
        await state.update_data(address="Самовывоз")
        await state.set_state(RequestFSM.payment_type)
        await c.message.answer("💳 <b>Выберите способ оплаты:</b>", reply_markup=kb_payment_type())

@router.message(RequestFSM.address)
async def process_address(m: Message, state: FSMContext):
    await state.update_data(address=m.text)
    await state.set_state(RequestFSM.payment_type)
    await m.answer("💳 <b>Способ оплаты:</b>", reply_markup=kb_payment_type())

@router.callback_query(RequestFSM.payment_type)
async def process_payment(c: CallbackQuery, state: FSMContext):
    await c.answer()
    await state.update_data(payment_type=c.data.split(":")[1])
    await state.set_state(RequestFSM.comment)
    await c.message.answer("💬 <b>Комментарий:</b>", reply_markup=kb_skip_comment())

@router.message(RequestFSM.comment)
@router.callback_query(F.data == "skip_comment", RequestFSM.comment)
async def process_comment(event: Message | CallbackQuery, state: FSMContext):
    if isinstance(event, CallbackQuery):
        await event.answer()
        await state.update_data(comment=None)
    else:
        await state.update_data(comment=event.text)
    
    data = await state.get_data()
    summary = (
        f"<b>📋 Проверка данных заказа:</b>\n\n"
        f"👤 Имя: {data['customer_name']}\n"
        f"📱 Тел: {data['phone']}\n"
        f"🚚 Тип: {'Доставка' if data['delivery_type'] == 'delivery' else 'Самовывоз'}\n"
        f"🏠 Адрес: {data['address']}\n"
        f"💳 Оплата: {data['payment_type']}\n"
        f"💬 Коммент: {data['comment'] or '—'}"
    )
    await state.set_state(RequestFSM.confirm)
    if isinstance(event, Message):
        await event.answer(summary, reply_markup=kb_confirm())
    else:
        await event.message.answer(summary, reply_markup=kb_confirm())

@router.callback_query(F.data == "order_confirm", RequestFSM.confirm)
async def order_confirm_final(c: CallbackQuery, state: FSMContext, config: Config):
    await c.answer()
    data = await state.get_data()

    async with get_sessionmaker()() as session:
        # Проверяем пользователя
        res = await session.execute(select(User).where(User.tg_id == c.from_user.id))
        user = res.scalar_one_or_none()
        
        if not user:
            user = await upsert_user(session, c.from_user.id, c.from_user.username, c.from_user.first_name, config.admin_ids)

        new_request = Request(
            user_id=user.id,
            product_id=data["product_id"],
            customer_name=data.get("customer_name"),
            phone=data.get("phone"),
            delivery_type=data.get("delivery_type"),
            address=data.get("address"),
            payment_type=data.get("payment_type"),
            comment=data.get("comment"),
            status=RequestStatus.NEW,
        )
        session.add(new_request)
        await session.commit()

    await state.clear()
    await safe_edit(c, "✅ <b>Заявка отправлена!</b>\nМы свяжемся с вами в ближайшее время.", reply_markup=kb_after_request_sent())

    # Уведомление админов
    for admin_id in config.admin_ids:
        try:
            await c.bot.send_message(admin_id, f"🔔 <b>Новый заказ!</b>\nОт: {data['customer_name']}\nТел: {data['phone']}")
        except Exception:
            continue